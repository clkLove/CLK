#ifndef WIDGET_H
#define WIDGET_H
#include <QSerialPortInfo>
#include <QSerialPort>
#include <QWidget>
#include <QTimer>

QT_BEGIN_NAMESPACE
namespace Ui {
class Widget;
}
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void on_BtnRefreshSerial_clicked();

    void on_BtnOpenOrClose_clicked();

    void on_checkBoxHEXDisplay_checkStateChanged(const Qt::CheckState &arg1);

    void on_BtnSendData_clicked();

    void on_checkBoxHEXSend_checkStateChanged(const Qt::CheckState &arg1);

    void on_checkBoxLineFeed_checkStateChanged(const Qt::CheckState &arg1);

    void on_checkBoxTimeSend_checkStateChanged(const Qt::CheckState &arg1);

    void on_BtnClearData_clicked();

    void on_BtnSaveData_clicked();

    void on_checkBox_1_checkStateChanged(const Qt::CheckState &arg1);

    void on_pushButton_1_clicked();

    void on_checkBox_2_checkStateChanged(const Qt::CheckState &arg1);

    void on_checkBox_3_checkStateChanged(const Qt::CheckState &arg1);

    void on_checkBox_4_checkStateChanged(const Qt::CheckState &arg1);

    void on_checkBox_5_checkStateChanged(const Qt::CheckState &arg1);

    void on_checkBox_6_checkStateChanged(const Qt::CheckState &arg1);

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_6_clicked();

private:
    Ui::Widget *ui;
    QSerialPort serialport;
    QList<QSerialPortInfo> seriallist;
    QTimer *timer;
    bool SerialConnect_Status;
    void Serialport_RecvData();
    bool HEXDisplay_Status;
    bool HEXSend_Status;
    bool TimeSend_Status;
    bool LineFeed_Status;
    void GetSysTime();
    int RecvDataSize;
    int SendDataSize;
    bool checkBox_1_status;
    bool checkBox_2_status;
    bool checkBox_3_status;
    bool checkBox_4_status;
    bool checkBox_5_status;
    bool checkBox_6_status;
    void Send_Data(bool HexStatus,QString SendString);
};
#endif // WIDGET_H
