#include "widget.h"
#include "ui_widget.h"
#include <QDebug>
#include <QFile>
#include<QString>
#include <qfiledialog.h>
Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    // 初始化UI界面
    ui->setupUi(this);
    // 设置布局
    this->setLayout(ui->gridLayout_8);

    // 初始化状态变量
    SerialConnect_Status=false;
    HEXDisplay_Status=false;
    LineFeed_Status=false;
    TimeSend_Status=false;
    checkBox_1_status=false;
    checkBox_2_status=false;
    checkBox_3_status=false;
    checkBox_4_status=false;
    checkBox_5_status=false;
    checkBox_6_status=false;

    // 初始化数据大小变量
    RecvDataSize=0;
    SendDataSize=0;

    // 设置默认波特率和数据位
    ui->comboBoxdatabit->setCurrentIndex(3);
    ui->comboBoxboautrate->setCurrentIndex(6);

    // 创建定时器
    timer=new QTimer(this);
    QTimer *SysTime=new QTimer(this);

    // 获取可用的串口列表
    seriallist=QSerialPortInfo::availablePorts();
    for(QSerialPortInfo serialInfo:seriallist){
        // qDebug()<<serialInfo.portName();             //调试行
        ui->comboBoxserialnum->addItem(serialInfo.portName());
    }

    // 连接串口读取信号和槽函数
    connect(&serialport,&QSerialPort::readyRead,[=](){
        Serialport_RecvData();
    });
    // 连接定时器和槽函数
    connect(timer,&QTimer::timeout,this,&Widget::on_BtnSendData_clicked);
    connect(SysTime,&QTimer::timeout,[=](){
        GetSysTime();
    });
    // 启动定时器
    SysTime->start(1000);
}

// 析构函数，用于释放Widget对象占用的内存
Widget::~Widget()
{
    // 删除ui指针指向的对象，释放内存
    delete ui;
}

void Widget::on_BtnRefreshSerial_clicked()
{
    // 清空下拉框
    ui->comboBoxserialnum->clear();
    // 获取可用的串口列表
    seriallist=QSerialPortInfo::availablePorts();
    // 遍历串口列表
    for(QSerialPortInfo serialInfo:seriallist){
        // qDebug()<<serialInfo.portName();             //调试行
        // 将串口名称添加到下拉框中
        ui->comboBoxserialnum->addItem(serialInfo.portName());
    }
}





void Widget::on_BtnOpenOrClose_clicked()
{
    // 如果串口未连接，则执行以下操作
    if(!SerialConnect_Status){
        // serialport.setParent(this);
        // 设置串口号
        serialport.setPortName(ui->comboBoxserialnum->currentText());
        // 设置波特率
        serialport.setBaudRate(ui->comboBoxboautrate->currentText().toInt());
        // 设置停止位
        serialport.setStopBits(QSerialPort::StopBits(ui->comboBoxstopbit->currentIndex()+1));
        // 设置数据位
        serialport.setDataBits(QSerialPort::DataBits(ui->comboBoxdatabit->currentText().toUInt()));


        // NoParity = 0,
        // EvenParity = 2,
        // OddParity = 3,
        // SpaceParity = 4,
        // MarkParity = 5
        switch (ui->comboBoxjiaoyw->currentIndex()) {
        case 0:
            serialport.setParity(QSerialPort::NoParity);
            break;
        case 1:
            serialport.setParity(QSerialPort::OddParity);
            break;
        case 2:
            serialport.setParity(QSerialPort::EvenParity);
            break;
        case 3:
            serialport.setParity(QSerialPort::MarkParity);
            break;
        case 4:
            serialport.setParity(QSerialPort::SpaceParity);
            break;
        default:
            break;
        }

        if(ui->comboBoxLiuk->currentText()=="None"){
            serialport.setFlowControl(QSerialPort::NoFlowControl);
        }
        if(serialport.open(QIODeviceBase::ReadWrite)){
            SerialConnect_Status=true;
            ui->BtnOpenOrClose->setText("关闭串口");
            ui->comboBoxserialnum->setEnabled(false);
            ui->comboBoxboautrate->setEnabled(false);
            ui->comboBoxdatabit->setEnabled(false);
            ui->comboBoxjiaoyw->setEnabled(false);
            ui->comboBoxstopbit->setEnabled(false);
            ui->comboBoxLiuk->setEnabled(false);
            ui->BtnRefreshSerial->setEnabled(false);

        }


    }else{
        serialport.close();
        SerialConnect_Status=false;
        ui->comboBoxserialnum->setEnabled(true);
        ui->comboBoxboautrate->setEnabled(true);
        ui->comboBoxdatabit->setEnabled(true);
        ui->comboBoxjiaoyw->setEnabled(true);
        ui->comboBoxstopbit->setEnabled(true);
        ui->comboBoxLiuk->setEnabled(true);
        ui->BtnRefreshSerial->setEnabled(true);
        ui->BtnOpenOrClose->setText("打开串口");
    }
}

void Widget::Serialport_RecvData()
{

    // 如果串口连接状态为真
    if(SerialConnect_Status){
        // 获取当前时间
        QDateTime currentTime=QDateTime::currentDateTime();
        // 获取当前日期
        QDate date=currentTime.date();
        // 获取当前时间
        QTime time=currentTime.time();
        // 将日期和时间格式化为字符串
        QString MyTime=QString("%1-%2-%3 %4:%5:%6 \n").arg(date.year()).arg(date.month()).arg(date.day())
                             .arg(time.hour()).arg(time.minute()).arg(time.second());

        // 读取串口数据
        QByteArray RecvMessage=serialport.readAll();
        // 更新接收数据大小
        RecvDataSize+=RecvMessage.size();
        // 如果HEX显示状态为假
        if(!HEXDisplay_Status){
            // 将接收到的数据转换为字符串并显示在文本框中
            QString TextDisplay="Rx:    "+MyTime+QString::fromUtf8(RecvMessage);
            ui->texDisplaytEdit->append(TextDisplay);
        }else{
            // 将接收到的数据转换为十六进制字符串
            QString HexStr=RecvMessage.toHex().toUpper();
            // 将十六进制字符串转换为可读的字符串
            QString HEXDispaly;
            qDebug()<<HexStr;
            for(int i=0;i<HexStr.size();i+=2){
                HEXDispaly=HEXDispaly+HexStr[i]+HexStr[i+1]+' ';
            }
            // 获取当前时间
            QDateTime currentTime=QDateTime::currentDateTime();
            QDate date=currentTime.date();
            QTime time=currentTime.time();
            // 将日期和时间格式化为字符串
            QString MyTime=QString("%1-%2-%3 %4:%5:%6 \n").arg(date.year()).arg(date.month()).arg(date.day())
                                 .arg(time.hour()).arg(time.minute()).arg(time.second());

            // 将十六进制字符串和日期时间格式化为可读的字符串并显示在文本框中
            HEXDispaly="Rx:  "+MyTime+HEXDispaly;
            ui->texDisplaytEdit->append(HEXDispaly);
            qDebug()<<HEXDispaly;
        }
        // 更新接收数据大小的标签
        QString lablrcvCnt="Rx:"+QString::number(RecvDataSize);
        ui->labelRecvCnt->setText(lablrcvCnt);
    }
}

// 获取系统时间
void Widget::GetSysTime()
{
    // 获取当前时间
    QDateTime currentTime=QDateTime::currentDateTime();
    // 获取当前日期
    QDate date=currentTime.date();
    // 获取当前时间
    QTime time=currentTime.time();
    // 将日期和时间格式化为字符串
    QString MyTime=QString("%1-%2-%3 %4:%5:%6 \n").arg(date.year()).arg(date.month()).arg(date.day())
                         .arg(time.hour()).arg(time.minute()).arg(time.second());
    // 将格式化后的时间字符串显示在标签上
    ui->labelNowTime->setText(MyTime);
}

void Widget::Send_Data(bool HexStatus,QString SendString)
{
    // 将SendString赋值给SendText
    QString SendText=SendString;
    // 如果HexStatus为false，则直接发送SendText
    if(!HexStatus){
        // 将SendText的长度加到SendDataSize上
        SendDataSize+=SendText.size();
        // 如果LineFeed_Status为true，则在SendText后添加换行符
        if(LineFeed_Status)SendText+="\n";
        // 将SendText转换为UTF-8编码，并通过串口发送
        serialport.write(SendText.toUtf8());
    }else{
        // QByteArray tmparry=SendText.toLocal8Bit();
        // 将SendText转换为十六进制字符串
        QString Hex;
        for(int i=0;i<SendText.size();i++){
            if(SendText[i]!=' '){
                Hex=Hex+SendText[i];
            }
        }
        // 将Hex的长度加到SendDataSize上
        SendDataSize+=Hex.size();
        // 将Hex转换为本地8位编码
        QByteArray tmparry=Hex.toLocal8Bit();
        // 如果tmparry的长度不是偶数，则发送错误信息
        if(tmparry.size()%2!=0){
            ui->labelSend_Statu->setText("Send Erro1");
            return;
        }
        // 遍历tmparry，如果存在非十六进制字符，则发送错误信息
        for(char c:tmparry){
            if(!std::isxdigit(c)){
                ui->labelSend_Statu->setText("Send Erro2");
                return;
            }
        }
        // 将tmparry转换为十六进制编码
        QByteArray HexSend=QByteArray::fromHex(tmparry);
        // 通过串口发送HexSend
        serialport.write(HexSend);
        // 发送成功，更新发送状态标签
        ui->labelSend_Statu->setText("Send OK");
    }

    // 获取当前时间
    QDateTime currentTime=QDateTime::currentDateTime();
    // 获取当前日期
    QDate date=currentTime.date();
    // 获取当前时间
    QTime time=currentTime.time();
    // 将日期和时间格式化为字符串
    QString MyTime=QString("%1-%2-%3 %4:%5:%6 \n").arg(date.year()).arg(date.month()).arg(date.day())
                         .arg(time.hour()).arg(time.minute()).arg(time.second());

    // 将发送的数据和时间拼接
    SendText="Tx:    "+MyTime+SendText;
    // 将发送的数据添加到文本框中
    ui->texDisplaytEdit->append(SendText);
    // 更新发送数据量的标签
    QString lablsendCnt="Tx:"+QString::number(SendDataSize);
    ui->labelSendCnt->setText(lablsendCnt);
}


// 当HEXDisplay复选框的状态改变时调用该函数
void Widget::on_checkBoxHEXDisplay_checkStateChanged(const Qt::CheckState &arg1)
{
    // 如果复选框被选中
    if(arg1==Qt::Checked){
        // 将HEXDisplay_Status设置为true
        HEXDisplay_Status=true;
    }else{
        // 否则将HEXDisplay_Status设置为false
        HEXDisplay_Status=false;
    }
}


void Widget::on_BtnSendData_clicked()
{
    // 如果串口连接状态为真
    if(SerialConnect_Status){

        // 获取发送文本
        QString SendText=ui->textEditSend->toPlainText();
        // 如果HEX发送状态为假
        if(!HEXSend_Status){
            // 发送数据大小增加发送文本的大小
            SendDataSize+=SendText.size();
            // 如果换行状态为真，则发送文本增加换行符
            if(LineFeed_Status)SendText+="\n";
            // 将发送文本转换为UTF8编码，并通过串口发送
            serialport.write(SendText.toUtf8());
        }else{
            // QByteArray tmparry=SendText.toLocal8Bit();
            // 将发送文本转换为十六进制字符串
            QString Hex;
            for(int i=0;i<SendText.size();i++){
                if(SendText[i]!=' '){
                    Hex=Hex+SendText[i];
                }
            }
            // 发送数据大小增加十六进制字符串的大小
            SendDataSize+=Hex.size();
            // 将十六进制字符串转换为本地8位编码
            QByteArray tmparry=Hex.toLocal8Bit();
            // 如果十六进制字符串的长度不是偶数，则发送错误1
            if(tmparry.size()%2!=0){
                ui->labelSend_Statu->setText("Send Erro1");
                return;
            }
            // 遍历十六进制字符串，如果字符不是十六进制字符，则发送错误2
            for(char c:tmparry){
                if(!std::isxdigit(c)){
                    ui->labelSend_Statu->setText("Send Erro2");
                    return;
                }
            }
            // 将十六进制字符串转换为字节数组
            QByteArray HexSend=QByteArray::fromHex(tmparry);
            // 通过串口发送字节数组
            serialport.write(HexSend);
            // 设置发送状态为发送成功
            ui->labelSend_Statu->setText("Send OK");
        }

        // 获取当前时间
        QDateTime currentTime=QDateTime::currentDateTime();
        // 获取当前日期
        QDate date=currentTime.date();
        // 获取当前时间
        QTime time=currentTime.time();
        // 将日期和时间格式化为字符串
        QString MyTime=QString("%1-%2-%3 %4:%5:%6 \n").arg(date.year()).arg(date.month()).arg(date.day())
                             .arg(time.hour()).arg(time.minute()).arg(time.second());

        // 将发送文本添加到显示文本框中
        SendText="Tx:    "+MyTime+SendText;
        ui->texDisplaytEdit->append(SendText);
        // 设置发送计数标签的文本为发送数据大小
        QString lablsendCnt="Tx:"+QString::number(SendDataSize);
        ui->labelSendCnt->setText(lablsendCnt);
    }
}


// 当复选框HEXSend的状态改变时，调用该函数
void Widget::on_checkBoxHEXSend_checkStateChanged(const Qt::CheckState &arg1)
{
    // 如果复选框HEXSend的状态为选中
    if(arg1==Qt::Checked){
        // 将HEXSend_Status设置为true
        HEXSend_Status=true;
    }else{
        // 否则将HEXSend_Status设置为false
        HEXSend_Status=false;
    }
}


// 当复选框的状态改变时，调用该函数
void Widget::on_checkBoxLineFeed_checkStateChanged(const Qt::CheckState &arg1)
{
    // 如果复选框的状态为选中
    if(arg1==Qt::Checked){
        // 设置换行状态为true
        LineFeed_Status=true;
    }else{
        // 否则，设置换行状态为false
        LineFeed_Status=false;
    }
}


// 当复选框TimeSend的状态改变时调用该函数
void Widget::on_checkBoxTimeSend_checkStateChanged(const Qt::CheckState &arg1)
{
    // 如果复选框被选中
    if(arg1==Qt::Checked){
        // 设置TimeSend_Status为true
        TimeSend_Status=true;
        // 启动定时器，定时器的时间间隔为lineEditTimeSend中的文本
        timer->start(ui->lineEditTimeSend->text().toInt());
    }else{
        // 设置TimeSend_Status为false
        TimeSend_Status=false;
        // 停止定时器
        timer->stop();
    }
}


// 当点击BtnClearData按钮时，执行以下操作
void Widget::on_BtnClearData_clicked()
{
    // 清空texDisplaytEdit文本框中的内容
    ui->texDisplaytEdit->clear();
}


void Widget::on_BtnSaveData_clicked()
{
    // 获取保存文件的文件名
    QString filename=QFileDialog::getSaveFileName(this,tr("Save File")
                                                    ,"D:/DATA/QT/serialData.txt"
                                                    ,tr("Text(*.txt)"));
    // 如果文件名不为空
    if(filename != ' '){
        // 创建一个QFile对象，用于保存文件
        QFile file(filename);
        // 以只写和文本模式打开文件
        if(!file.open(QIODevice::WriteOnly|QIODevice::Text)){
            // 如果打开文件失败，则返回
            return;
        }
        // 创建一个QTextStream对象，用于写入文件
        QTextStream out(&file);
        // 将texDisplaytEdit中的文本写入文件
        out<<ui->texDisplaytEdit->toPlainText();
        // 关闭文件
        file.close();
        // 清空texDisplaytEdit中的文本
        ui->texDisplaytEdit->clear();
    }
}


// 当复选框1的状态改变时调用该函数
void Widget::on_checkBox_1_checkStateChanged(const Qt::CheckState &arg1)
{
    // 如果复选框1的状态为选中
    if(arg1==Qt::Checked){
        // 将复选框1的状态设置为选中
        checkBox_1_status=true;
    }else{
        // 否则将复选框1的状态设置为未选中
        checkBox_1_status=false;
    }
}



// 当复选框2的状态改变时调用该函数
void Widget::on_checkBox_2_checkStateChanged(const Qt::CheckState &arg1)
{
    // 如果复选框2的状态为选中
    if(arg1==Qt::Checked){
        // 将复选框2的状态设置为true
        checkBox_2_status=true;
    }else{
        // 否则将复选框2的状态设置为false
        checkBox_2_status=false;
    }
}


// 当checkBox_3的状态改变时，调用该函数
void Widget::on_checkBox_3_checkStateChanged(const Qt::CheckState &arg1)
{
    // 如果arg1的值为Qt::Checked，则将checkBox_3_status设置为true
    if(arg1==Qt::Checked){
        checkBox_3_status=true;
        // 否则，将checkBox_3_status设置为false
    }else{
        checkBox_3_status=false;
    }
}


// 当复选框4的状态改变时调用该函数
void Widget::on_checkBox_4_checkStateChanged(const Qt::CheckState &arg1)
{
    // 如果复选框4的状态为选中
    if(arg1==Qt::Checked){
        // 将复选框4的状态设置为true
        checkBox_4_status=true;
    }else{
        // 否则将复选框4的状态设置为false
        checkBox_4_status=false;
    }
}


// 当复选框5的状态改变时调用该函数
void Widget::on_checkBox_5_checkStateChanged(const Qt::CheckState &arg1)
{
    // 如果复选框5的状态为选中
    if(arg1==Qt::Checked){
        // 将复选框5的状态设置为true
        checkBox_5_status=true;
    }else{
        // 否则将复选框5的状态设置为false
        checkBox_5_status=false;
    }
}


// 当复选框6的状态改变时调用该函数
void Widget::on_checkBox_6_checkStateChanged(const Qt::CheckState &arg1)
{
    // 如果复选框6的状态为选中
    if(arg1==Qt::Checked){
        // 将复选框6的状态设置为true
        checkBox_6_status=true;
    }else{
        // 否则将复选框6的状态设置为false
        checkBox_6_status=false;
    }
}


void Widget::on_pushButton_1_clicked()
{
    // 检查串口连接状态
    if(SerialConnect_Status){
        // 获取lineEdit_1中的文本
        QString Stext=ui->lineEdit_1->text();
        // 发送数据
        Send_Data(checkBox_1_status,Stext);
    }

}

void Widget::on_pushButton_2_clicked()
{
    // 如果串口连接状态为真
    if(SerialConnect_Status){
        // 获取lineEdit_2中的文本
        QString Stext=ui->lineEdit_2->text();
        // 发送数据
        Send_Data(checkBox_2_status,Stext);
    }

}


void Widget::on_pushButton_3_clicked()
{
    // 如果串口连接状态为真
    if(SerialConnect_Status){
        // 获取lineEdit_3中的文本
        QString Stext=ui->lineEdit_3->text();
        // 发送数据
        Send_Data(checkBox_3_status,Stext);
    }

}


void Widget::on_pushButton_4_clicked()
{
    // 如果串口连接状态为真
    if(SerialConnect_Status){
        // 获取lineEdit_4中的文本
        QString Stext=ui->lineEdit_4->text();
        // 发送数据
        Send_Data(checkBox_4_status,Stext);
    }

}


void Widget::on_pushButton_5_clicked()
{
    // 如果串口连接状态为真
    if(SerialConnect_Status){
        // 获取lineEdit_5中的文本
        QString Stext=ui->lineEdit_5->text();
        // 发送数据
        Send_Data(checkBox_5_status,Stext);
    }

}


void Widget::on_pushButton_6_clicked()
{
    // 如果串口连接状态为真
    if(SerialConnect_Status){
        // 获取lineEdit_6中的文本
        QString Stext=ui->lineEdit_6->text();
        // 发送数据
        Send_Data(checkBox_6_status,Stext);
    }

}



